.. cmake-module:: ../../Modules/CMakePushCheckState.cmake
