#pragma once

namespace MathFunctions {
double add(double x, double y);
}
