/* crc32.c -- compute the CRC-32 of a data stream
 * Copyright (C) 1995-2006, 2010, 2011, 2012, 2016 Mark Adler
 * For conditions of distribution and use, see copyright notice in zlib.h
 *
 * Thanks to Rodney Brown <rbrown64@csc.com.au> for his contribution of faster
 * CRC methods: exclusive-oring 32 bits of data at a time, and pre-computing
 * tables for updating the shift register in one step with three exclusive-ors
 * instead of four steps with four exclusive-ors.  This results in about a
 * factor of two increase in speed on a Power PC G4 (PPC7455) using gcc -O3.
 */

/* @(#) $Id$ */

/*
  Note on the use of DYNAMIC_CRC_TABLE: there is no mutex or semaphore
  protection on the static variables used to control the first-use generation
  of the crc tables.  Therefore, if you #define DYNAMIC_CRC_TABLE, you should
  first call get_crc_table() to initialize the tables before allowing more than
  one thread to use crc32().

  DYNAMIC_CRC_TABLE and MAKECRCH can be #defined to write out crc32.h.
 */

#ifdef MAKECRCH
#  include <stdio.h>
#  ifndef DYNAMIC_CRC_TABLE
#    define DYNAMIC_CRC_TABLE
#  endif /* !DYNAMIC_CRC_TABLE */
#endif /* MAKECRCH */

#include "zutil.h"      /* for STDC and FAR definitions */

/* Definitions for doing the crc four data bytes at a time. */
#if !defined(NOBYFOUR) && defined(Z_U4)
#  define BYFOUR
#endif
#ifdef BYFOUR
   local unsigned long crc32_little OF((unsigned long,
                        const unsigned char FAR *, z_size_t));
   local unsigned long crc32_big OF((unsigned long,
                        const unsigned char FAR *, z_size_t));
#  define TBLS 8
#else
#  define TBLS 1
#endif /* BYFOUR */

/* Local functions for crc concatenation */
local unsigned long gf2_matrix_times OF((unsigned long *mat,
                                         unsigned long vec));
local void gf2_matrix_square OF((unsigned long *square, unsigned long *mat));
local uLong crc32_combine_ OF((uLong crc1, uLong crc2, z_off64_t len2));


#ifdef DYNAMIC_CRC_TABLE

local volatile int crc_table_empty = 1;
local z_crc_t FAR crc_table[TBLS][256];
local void make_crc_table OF((void));
#ifdef MAKECRCH
   local void write_table OF((FILE *, const z_crc_t FAR *));
#endif /* MAKECRCH */
/*
  Generate tables for a byte-wise 32-bit CRC calculation on the polynomial:
  x^32+x^26+x^23+x^22+x^16+x^12+x^11+x^10+x^8+x^7+x^5+x^4+x^2+x+1.

  Polynomials over GF(2) are represented in binary, one bit per coefficient,
  with the lowest powers in the most significant bit.  Then adding polynomials
  is just exclusive-or, and multiplying a polynomial by x is a right shift by
  one.  If we call the above polynomial p, and represent a byte as the
  polynomial q, also with the lowest power in the most significant bit (so the
  byte 0xb1 is the polynomial x^7+x^3+x+1), then the CRC is (q*x^32) mod p,
  where a mod b means the remainder after dividing a by b.

  This calculation is done using the shift-register method of multiplying and
  taking the remainder.  The register is initialized to zero, and for each
  incoming bit, x^32 is added mod p to the register if the bit is a one (where
  x^32 mod p is p+x^32 = x^26+...+1), and the register is multiplied mod p by
  x (which is shifting right by one and adding x^32 mod p if the bit shifted
  out is a one).  We start with the highest power (least significant bit) of
  q and repeat for all eight bits of q.

  The first table is simply the CRC of all possible eight bit values.  This is
  all the information needed to generate CRCs on data a byte at a time for all
  combinations of CRC register values and incoming bytes.  The remaining tables
  allow for word-at-a-time CRC calculation for both big-endian and little-
  endian machines, where a word is four bytes.
*/
local void make_crc_table()
{
    z_crc_t c;
    int n, k;
    z_crc_t poly;                       /* polynomial exclusive-or pattern */
    /* terms of polynomial defining this crc (except x^32): */
    static volatile int first = 1;      /* flag to limit concurrent making */
    static const unsigned char p[] = {0,1,2,4,5,7,8,10,11,12,16,22,23,26};

    /* See if another task is already doing this (not thread-safe, but better
       than nothing -- significantly reduces duration of vulnerability in
       case the advice about DYNAMIC_CRC_TABLE is ignored) */
    if (first) {
        first = 0;

        /* make exclusive-or pattern from polynomial (0xedb88320UL) */
        poly = 0;
        for (n = 0; n < (int)(sizeof(p)/sizeof(unsigned char)); n++)
            poly |= (z_crc_t)1 << (31 - p[n]);

        /* generate a crc for every 8-bit value */
        for (n = 0; n < 256; n++) {
            c = (z_crc_t)n;
            for (k = 0; k < 8; k++)
                c = c & 1 ? poly ^ (c >> 1) : c >> 1;
            crc_table[0][n] = c;
        }

#ifdef BYFOUR
        /* generate crc for each value followed by one, two, and three zeros,
           and then the byte reversal of those as well as the first table */
        for (n = 0; n < 256; n++) {
            c = crc_table[0][n];
            crc_table[4][n] = ZSWAP32(c);
            for (k = 1; k < 4n++) {d] = r66i0by b. ZSWAk{d] = r66i0by b. ZSWAk{d] =  b. ZSWoeffd2-           crc_table[0][n] = c;
        }

#ifdef BYFOUR
        /* generate crc for each value followed by one, two, and three zeros,
           and then the byte reversal of those as well as the first table */
        for (n = 0; n < 256; n++) {
          or (n = 0; n < 256; + owed by one, two, and three zero}           F((unsigned long *squor (n = 0; n < 25te-wise 3 c = (z}     id g {n];
     xclueffd2-     crc_ta   waialues ZSWo     fguytly alresh excluresent a bern frf w; n++) {
    the   (0; n < 25te-wiste reversal ofc = (z} 10+x^8+x^7+x^5+x^4+xa   w definitive-ohe lowe2().ns */
 n++) {
he byte re GF(2)nit  crc_tableniti=luepen(".ns */
", "w" and three t)1 niti== NUL6; returree zeros,
fpr fof nit, "rown64@cshUL) he lowest praprstve-or pattern *\n" and three fpr fof nit, " *,
  with  vauto
  ee a y
   n64@csc\};

\*\n" and three fpr fof nit, "e int re represented in " and three fpr fof nit, " on the polynomial:
 =\n{\}; {\n" and three Polynomials nit, ose as well  long = crc_table[0][n];
  fpr fof nit, " = crc_table[\n" and three f,
           an8 then the byte reversfpr fof nit, "  },\}; {\n" and three ree Polynomials nit, ose as welk])            ][n];
  fpr fof nit, " ((uns\n" an)
#  define d long *sqe reversfpr fof nit, "  }\n};\n" and three f		</F nit)c = (z} y, one bit per coeffic} 10+x^8+x^7+x^5+x^^2+x+1.

  Polynomials nit, mialste rev GF(2)nit   revre represented in bmials;ag to l maki  crc_tble[0][n] = c;
        }
qe reversfpr fof nit, "%s0x%08lxUL%s", n % 5l a""le e OF("ifdef DYNAMIC_CRC_S][256];
local)(as wel   ifdef DYNAMIC_CRC_ni== 255l a"\n"le (n % 5l== 4l a",\n"le ", "inar} y, one bit per coefficvoid gine BYFOUR
#endif
#ifdef Bne ========================================================================ree ee lowe{
    -32sd-at-a-ts p+defAk{d]
    i,crcdSWAkt = 1;      /* fl
/* De long crc3.ns */
" y, one bitYFOUR
#endif
#ifdef BBne =========================================================================ree eake gned lon  /* for crc3Aktasm  r66le()
{
 dif /* /* Dere represented in b ZEXPORTef DYNAMIC_CRC_Tag );
#endif /* MAKECRCH */
to l f (0; n < 25te-wiste reversa = 1;      /* fl; y, one bitYFOUR
#endif
#ifdef Bersareturr (0e represented in bi      /* ar} Bne =========================================================================* De NOBYFOURO1rc_tathose as well a(  forc_tat t*buf }
) the first tarable */e NOBYFOURO8URO1;URO1;URO1;URO1;URO1;URO1;URO1;URO1 Bne =========================================================================* De_crc_table OF(ZEXPORTeCRCH
 ztarabernf,rc_tte revnsigned long gf2_   revre rep                   rnf*/
    snsignerc_t;ag to l f (rnfl== Z_NUL6; returr 256;*));
#endif /* MAKECRCH */
to l f (0; n < 25te-wiste reversa = 1;      /* fl; y, one bitYFOUR
#endif
#ifdef Bc = crc_table[0][n] f (< 8; k+.

  *)l== (k = 0; tronefned the byte reresentedng thi  crc_tableng this=       for ( f (*(++)
           *)(&ng thi))te reversal ofreturr e TBLS 8
#eltarabernf,rc_tt     for (id gf reversal ofreturr e TBLSbigtarabernf,rc_tt     f  F((unsigned long *sq revr_tathosest e fiiiiiii56;* revthe   (c_t >= */the byte reRO8     for (c_t -= *c = (z}      f (c_tt   the byte reRO      f}vthe   (--c_tt     freturr e Tst e fiiiiiii56;*} Bne =========================================================================* De_crc_table OF(ZEXPORTeCRCH
tarabernf,rc_tte revnsigned long gf2_   revre rep                   rnf*/
   uInerc_t;ag to lreturr e TBLSztarabernf,rc_tt;
  c = crc_table[0cient, eake d long 	>
 acelateinder. ascrc3+)
           *ernff  f dataae most nt,  foeg  fpo foes Zype. eake vir
  einder.s foctt-aias p+xrulecept x^32
revre	Relat  /* ascuwer ble[oool"
			/> purp</Fsalizatfirstpo foeswe2(
revgnedaMapFil y
onefetion Zype{d]on't

#iftpo foe start saMa memory.a one (w)(sizmostBuil b. alowi/* m    y
 f ht b can bepo foeswene Polyt b. o.a one (>
(siz   y
ve-os*/
   . ZSWApo foesw. Solong gb. ZSne (>
;      wener
  ednt)(sizZSne (>	Rel			/> unted
 initi]on't
be alowi/* m.re-cotatic vason, ZSne (>
(size <std xclubft ret taPC G4resudnt) sta (>	Rel			/> untegistthe CR     f(>
(sizPolynse start rnff  fizatf
  qascrc3 startSWAro55) volaef BBne =========================================================================* De NOBYFOUROLIT4of ^=  rnf4++; \uor (n = 0athose as wel3 as the first ose as wel2 a(able */ the first \f reversal ofose as wel1 a(able 16) the first ose as well as le 24]e NOBYFOUROLIT32UROLIT4;UROLIT4;UROLIT4;UROLIT4;UROLIT4;UROLIT4;UROLIT4;UROLIT4BBne =========================================================================* Dez_size_t));
#  define TBLS 8
#eltarabernf,rc_tte revnsigned long gf2_   revre rep                   rnf*/
    snsignerc_t;ag to l_crc_t c;imit concurrent_crc_t c;0e represented in brnf4  crc_t, two, and thf2_   revr tw~c;* revthe   (c_t && (; tronefnedrnfl& 3d the byte retathose as well a(Tst *buf }
 the first table */
        fc_t--c = (z} 1= (zrnf4 two0e represented in bio0e rep.

   in birnf*/
   the   (c_t >=  eache byte reROLIT32     for (c_t -= 32     f}/
   the   (c_t >= 4ache byte reROLIT4     for (c_t -= 4     f}/
   rnfl=wo0e rep                   )rnf4  crc_t f (c_tt   the byte retathose as well a(Tst *buf }
 the first table */
     }vthe   (--c_tt     fr tw~c;* revreturr (][256];
local)car} Bne =========================================================================* De NOBYFOUROBIG4of ^=  rnf4++; \uor (n = 0athose as wel4 as the first ose as wel5 a(able */ the first \f reversal ofose as wel6 a(able 16) the first ose as wel7 as le 24]e NOBYFOUROBIG32UROBIG4;UROBIG4;UROBIG4;UROBIG4;UROBIG4;UROBIG4;UROBIG4;UROBIG4BBne =========================================================================* Dez_size_t));
#  define TBLSbigtarabernf,rc_tte revnsigned long gf2_   revre rep                   rnf*/
    snsignerc_t;ag to l_crc_t c;imit concurrent_crc_t c;0e represented in brnf4  crc_t, twone, twoo, and thf2_t     fr tw~c;* revthe   (c_t && (; tronefnedrnfl& 3d the byte retathose as wel4 a(able 24act *buf }rst tab<< */
        fc_t--c = (z} 1= (zrnf4 two0e represented in bio0e rep.

   in birnf*/
   the   (c_t >=  eache byte reROBIG32     for (c_t -= 32     f}/
   the   (c_t >= 4ache byte reROBIG4;    for (c_t -= 4     f}/
   rnfl=wo0e rep                   )rnf4  crc_t f (c_tt   the byte retathose as wel4 a(able 24act *buf }rst tab<< */
     }vthe   (--c_tt     fr tw~c;* revreturr (][256];
local)(one, two, t;
  c ((unsigned long *squ NOBYFOUGF2_DIMncreeeeeegnediMaps  for (ne.  Iv	</Fis (c_tgata{
    )ef BBne =========================================================================* De_combine_ OF((uLong crc1, uLong crc2(

#ipty =e revnsigned long g(voi;e revnsigned long gty ;ag to lnsigned long gcuw  crc_tcuwe 3 c = (zthe   (ty =the byte re f (ty  welte reversal ofcuwe^=  voi;e revvvvvty  >>=       for (voi++;    f}/
   returr cuw  } Bne =========================================================================* De
local z_crc_t FAR crc_table(oid makevoide revnsigned long g(oid ma;e revnsigned long g voi;eg to l maki  crc_tble[0][n] = c;
 GF2_DIM    }
qe reversoid maed by crc1, uLong crc2(

#ip

#      } Bne =========================================================================* De
localf MAKECRCH
   local (table LE *, c_t Fe revnrite_tabl;e revnrite_tab2*/
    snst z_crc_t ;eg to l maki   revnsigned long grow   revnsigned long gMake[GF2_DIM];eeeegneMake- time-of-irst k <  Buil.tlb *sq revnsigned long godd[GF2_DIM];eeeeegneodd- time-of-irst k <  Buil.tlb *sq
eeeegnede       crc)/si(is dodis    /*neg
</V c_tgats= (z_crc_t)1 c_t  <n] 
qe reversreturr e T1   if (firput Buil.tlb ble[on1; k <t poweneodd (z_crc_odd[0 by = 0; n < 256t unsigned /*s contri     for (nf Bersar /*=       fble[0][n]1= c;
 GF2_DIM    }
the byte reodd[d by row   reversar /*<<=       f}  if (firput Buil.tlb ble[irst k <ing byeneMakenf Bersac_t FAR crc_table(Make,eodd)   if (firput Buil.tlb ble[ stat k <ing byeneodd (z_crc_c_t FAR crc_table(odd,eMake)   if (firaplow c_t   k <  2().ns11 << (3soid ma wia-tiut ZSWo uil.tlb ble[on1  revers k <inytakealcula k <ing b,yeneMake= (z_crc_  the byte refiraplow  k <  Buil.tlb f-cotatic pow{
 c_t  *sqe reversc_t FAR crc_table(Make,eodd)  e reverst)1 c_t  welte reversal of.ns11y crc1, uLong crc2(Make,e.ns1/
        fc_t2 >>=    e byte refirt)1ze t /* ng bysetalized od p *sqe reverst)1 c_t  =n] 
qe reversssssbreak  e byte refir       fite     for (ing thouse of odd PC GMakenswapled *sqe reversc_t FAR crc_table(odd,eMake)  e reverst)1 c_t  welte reversal of.ns11y crc1, uLong crc2(odd,e.ns1/
        fc_t2 >>=    e byte refirt)1ze t /* ng bysetalized od p *sqe re} the   (c_t2 !n] 
   if (firreturr e locald e Ts*sq revr_t1e^= tab2*/
   returr e T1  } Bne =========================================================================* De_L OF(ZEXPORTeCRCH
 e local(table LE *, c_t Fe revnrite_tabl;e revnrite_tab2*